#ifndef WORDS_H
#define WORDS_H
char **split_words(char *);
void free_words(char **);
#endif
